<template>
  <div class="top" v-show="chatBoxHeader?.showChatBoxHeader">
    <svg
      @click="$emit('close')"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g id="close">
        <path
          id="Union"
          d="M12.7593 11.7187L17.1793 7.29871C17.253 7.23005 17.3121 7.14725 17.3531 7.05525C17.3941 6.96325 17.4162 6.86393 17.4179 6.76323C17.4197 6.66253 17.4012 6.5625 17.3635 6.46911C17.3257 6.37572 17.2696 6.29089 17.1984 6.21967C17.1272 6.14845 17.0423 6.09231 16.9489 6.05459C16.8555 6.01686 16.7555 5.99834 16.6548 6.00012C16.5541 6.00189 16.4548 6.02394 16.3628 6.06493C16.2708 6.10592 16.188 6.16502 16.1193 6.23871L11.6993 10.6587L7.27934 6.23871C7.13716 6.10623 6.94912 6.0341 6.75482 6.03753C6.56052 6.04096 6.37513 6.11967 6.23772 6.25709C6.10031 6.3945 6.02159 6.57988 6.01816 6.77419C6.01474 6.96849 6.08686 7.15653 6.21934 7.29871L10.6393 11.7187L6.21934 16.1387C6.07889 16.2793 6 16.47 6 16.6687C6 16.8675 6.07889 17.0581 6.21934 17.1987C6.35997 17.3392 6.55059 17.418 6.74934 17.418C6.94809 17.418 7.13871 17.3392 7.27934 17.1987L11.6993 12.7787L16.1193 17.1987C16.26 17.3392 16.4506 17.418 16.6493 17.418C16.8481 17.418 17.0387 17.3392 17.1793 17.1987C17.3198 17.0581 17.3987 16.8675 17.3987 16.6687C17.3987 16.47 17.3198 16.2793 17.1793 16.1387L12.7593 11.7187Z"
          fill="#25282E"
        />
      </g>
    </svg>
    <p>{{ chatBoxHeader?.title }}</p>
  </div>

  <div class="Chat-Box" v-if="!chatMessages?.length">
    <div class="chatbox-header">
      <img :src="chatBoxStyle.logo" />
      <p>{{ emptyChatContent?.title }}</p>
    </div>

    <div className="chat-box-input">
      <input
        type="text"
        :placeholder="emptyChatContent?.inputPlaceholder"
        v-model="inputText"
      />
      <div @click="SendMessage">
        <img :src="emptyChatContent?.searchIcon" />
      </div>
    </div>

    <div className="chat-box-Suggestion">
      <span
        ><img :src="savedTemplates?.icon" /> {{ savedTemplates?.title }}</span
      >

      <div v-for="data in savedTemplates.templates" :key="data?.title">
        {{ data?.title }}
      </div>
    </div>
  </div>
  <div class="chat-ui" v-else>
    <div
      class="chat_container chat-box"
      :style="{ height: chatBoxInnerHeight }"
    >
      <div
        v-for="(message, index) in chatMessages"
        :key="index"
        :class="message.isAI ? 'wrapper-ai' : 'wrapper-user'"
      >
        <div v-if="!message.isAI" class="chat">
          <div class="chat-profile-info">
            <div class="profile-icon">
              <img :src="userIcon" alt="" />
            </div>
            <div class="profile-info">
              <span class="user-name">shubham </span>
              <span class="chat-date">12/june/2001</span>
            </div>
          </div>
          <div class="message">
            {{ message.text }}
          </div>
        </div>
        <div v-if="message.isAI" class="chat-ai">
          <div class="chat-profile-info">
            <div class="profile-icon" style="padding: 5px">
              <img :src="chatBoxStyle.logo" alt="" />
            </div>
            <div class="ai-profile-head">
              <div class="profile-info">
                <span class="user-name">Ai Logi </span>
                <span class="chat-date">12-06-2883</span>
              </div>
            </div>
          </div>
          <div>
            <div class="loading-animation" v-if="message.isDisabled">
              <div class="item">
                <div class="skeleton title"></div>
                <div class="skeleton content"></div>
                <div class="skeleton content"></div>
                <div class="skeleton content"></div>
              </div>
            </div>
            <div v-if="!message?.isChatActionArea">
              <div v-if="!message.chart" class="message" :id="message.id">
                {{ message.text }}
              </div>
            </div>
            <div v-if="message?.isChatActionArea" class="chatbox-action-area">
              <hds-area-action
                :areaActionOption="message?.areaActionButtonOption"
                @areaActionHandler="areaActionClickHandler"
              ></hds-area-action>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="chat-form" @submit.prevent="SendMessage">
      <div class="chat-input-group">
        <div class="chat-icon">
          <img :src="chatBoxStyle?.logo" alt="" />
        </div>
        <input
          type="text"
          name="query"
          :placeholder="chatBoxStyle?.inputBoxPlaceholder"
          class="chat-textbox"
          v-model="inputText"
          autocomplete="off"
          :disabled="isInputDisabled"
          :readonly="isInputDisabled"
        />
        <div class="chat-icon">
          <i></i>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  name: "ChatComponent",
  emits: ["close", "SentMessage"],
  props: {
    chatBoxStyle: {
      type: Object,
    },
    emptyChatContent: {
      type: Object,
    },
    chatBoxHeader: {
      type: Object,
    },
    savedTemplates: Object,
    chatMessages: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      inputText: "",
    };
  },
  methods: {
    SendMessage() {
      const obj = {
        isAI: false,
        text: this.inputText,
        id: `${this.chatMessages?.length}`,
        chart: false,
        chartInfo: {},
        isChatActionArea: false,
        areaActionButtonOption: {
          title: "Recomandation",
          height: "100px",
          width: "300px",
          primaryButtonText: "Pin to Broad",
          primaryButtonType: "primary",
          secondaryButtonType: "secondary",
          secondaryButtonText: "Preview",
          primaryButtonIcon: "pi pi-eye",
          secondaryButtonIcon: "pi pi-comments",
        },
        isDisabled: false,
        date: new Date().toISOString(),
      };

      this.$emit("SentMessage", obj);
      this.inputText = "";
    },
  },
};
</script>

<style>
@import "../../css/variable.css";

.top {
  padding: 1rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  grid-gap: 20px;
}
.top p {
  font-size: 18px;
  margin: 0;
  font-weight: 600;
}
.Chat-Box {
  padding: 1rem;
  background: var(--hds-chatbox-background);
  flex: 1;
}

.chatbox-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  grid-gap: var(--hds-chatbox-header-gap);
  padding: var(--hds-chatbox-header-paddingY);
}
.chatbox-header > img {
  width: var(--hds-chatbox-header-logo-width);
  height: var(--hds-chatbox-header-logo-height);
}
.chatbox-header > p {
  margin: 0;
  font-size: var(--hds-chatbox-header-text);
  font-weight: var(--hds-chatbox-header-text-weight);
}

.chat-box-input {
  display: flex;
  padding: var(--hds-chatbox-header-paddingY);
}
.chat-box-input input {
  width: var(--hds-chatbox-input-width);
  height: var(--hds-chatbox-input-height);
  border: var(--hds-chatbox-input-border);
  border-radius: var(--hds-chatbox-input-border-radius);
  background: var(--hds-chatbox-input-background);
  padding: var(--hds-chatbox-input-padding);
  outline: none;
}
.chat-box-input > div {
  border-radius: var(--hds-chatbox-input-search-border-radius);
  background: var(--hds-chatbox-input-search-background);
  padding: var(--hds-chatbox-input-search-padding);
  height: var(--hds-chatbox-input-height);
  display: flex;
  justify-content: center;
  align-items: center;
}

.chat-box-Suggestion > span {
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--hds-chatbox-saved-template-head-color);
  grid-gap: var(--hds-chatbox-saved-template-head-gap);
  font-size: var(--hds-chatbox-saved-template-head-font-size);
  font-weight: var(--hds-chatbox-saved-template-head-font-weight);
}
.chat-box-Suggestion > div {
  grid-gap: 10px;
  background: var(--hds-chatbox-saved-template-card-background);
  border: var(--hds-chatbox-saved-template-card-border);
  border-radius: var(--hds-chatbox-saved-template-card-border-radius);
  padding: var(--hds-chatbox-saved-template-card-padding);
  color: var(--hds-chatbox-saved-template-card-color);
  font-size: var(--hds-chatbox-saved-template-card-font-size);
  font-weight: var(--hds-chatbox-saved-template-card-font-weight);
  cursor: pointer;
  margin: var(--hds-chatbox-saved-template-list-margin);
}

.chat-ui {
  background: var(--hds-chatbox-background);
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  overflow-y: scroll;
}
.chat-ui::-webkit-scrollbar,
.chat-ui::-webkit-scrollbar-thumb {
  display: none;
}

.chat-ui .chat-box {
  width: var(--hds-chatbox-width);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: var(--hds-chatbox-padding);
  gap: var(--hds-chatbox-gap);
}
.chat_container {
  flex: 1;
  width: 100%;

  overflow-y: scroll;
  display: flex;
  flex-direction: column;
  gap: var(--hds-chatbox-container-gap);
  -ms-overflow-style: none;
  scrollbar-width: none;
  scroll-behavior: smooth;
  max-width: 300px;
  margin: 1rem;
}

.chat_container::-webkit-scrollbar {
  display: none;
}

.chat_container::-webkit-scrollbar-thumb {
  background: #b2b2b2c1;
  border-radius: 80px;
}
.wrapper-user {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  flex-direction: row-reverse;
}

.wrapper-user .chat {
  width: var(--hds-chatbox-container-chat-width);
  background: var(--hds-chatbox-container-chat-background);
  border-radius: var(--hds-chatbox-container-border-radius);
  box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.08);
}
.wrapper-user .message {
  color: var(--hds-chatbox-container-message-color);
  font-style: normal;
  font-weight: 400;
  font-size: var(--hds-chatbox-container-message-font-size);
  flex: none;
  order: 0;
  flex-grow: 1;
  padding: var(--hds-chatbox-container-message-padding);
}

.chat-profile-info {
  display: flex;
  align-items: flex-start;
  gap: var(--hds-chatbox-chat-profile-gap);
  padding: var(--hds-chatbox-chat-profile-padding);
  border-bottom: var(--hds-chatbox-chat-profile-border-bottom);
}
.chat-profile-info .profile-icon {
  height: var(--hds-chatbox-chat-profile-height);
  width: var(--hds-chatbox-chat-profile-width);
  border-radius: var(--hds-chatbox-chat-profile-border-radius);
  overflow: hidden;
  background: var(--hds-chatbox-chat-profile-background);
}

.chat-profile-info .profile-icon img {
  height: 100%;
  width: 100%;
}
.chat-profile-info .profile-info {
  display: flex;
  flex-direction: column;
  gap: 3;
}

.chat-profile-info .profile-info .user-name {
  font-size: var(--hds-chatbox-chat-profile-font-size);
  font-weight: var(--hds-chatbox-chat-profile-font-weight);
  color: #343a40;
}

.chat-profile-info .profile-info .chat-date {
  color: var(--hds-chatbox-chat-profile-date-font-color);
  font-size: var(--hds-chatbox-chat-profile-date-font-size);
  font-weight: var(--hds-chatbox-chat-profile-date-font-weight);
}

.loading-animation .item {
  vertical-align: top;
  background: #ffffff;
  border-radius: 3px;
  padding: 16px;
  width: 100%;
}

@keyframes placeHolderShimmer {
  0% {
    background-position: -500px 0;
  }
  100% {
    background-position: 500px 0;
  }
}

.loading-animation .skeleton {
  animation-duration: 1s;
  animation-fill-mode: forwards;
  animation-iteration-count: infinite;
  animation-name: placeHolderShimmer;
  animation-timing-function: linear;
  background: #f6f7f8;
  background: linear-gradient(to right, #eeeeee 8%, #dddddd 18%, #eeeeee 33%);
  background-size: 1200px 100px;
}

.loading-animation .title {
  height: 20px;
  width: 200px;
  margin-top: 8px;
  margin-bottom: 26px;
}

.loading-animation .content {
  height: 20px;
  width: 100%;
  margin-bottom: 8px;
}
.wrapper-ai {
  width: var(--hds-chatbox-warpper-input-width);
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  gap: var(--hds-chatbox-warpper-input-gap);
}

.wrapper-ai .chat-ai {
  width: var(--hds-chatbox-warpper-input-width);
  gap: var(--hds-chatbox-warpper-input-gap);
  background: var(--hds-chatbox-warpper-input-background);
  border: var(--hds-chatbox-warpper-input-border);
  border-radius: var(--hds-chatbox-warpper-input-border-radius);
}

.wrapper-ai .ai-profile-head {
  display: grid;
  grid-template-columns: var(
    --hds-chatbox-warpper-profile-head-grid-template-columns
  );
  width: var(--hds-chatbox-warpper-profile-head-width);
}

.wrapper-ai .message {
  color: var(--hds-chatbox-warpper-message-color);
  font-style: normal;
  font-weight: var(--hds-chatbox-warpper-message-font-weight);
  font-size: var(--hds-chatbox-warpper-message-font-size);
  max-width: 100%;
  white-space: pre-line;
  padding: var(--hds-chatbox-warpper-message-padding);
}

.wrapper-ai .message.bot-message {
  float: left;
}

.chatbox-action-area {
  padding: var(--hds-chatbox-action-area-padding);
}

.profile img {
  height: var(--hds-chatbox-profile-img-height);
  object-fit: contain;
}

.message::-webkit-scrollbar {
  display: none;
}

.chat-form {
  width: var(--hds-chatbox-form-width);
  height: var(--hds-chatbox-form-height);
  background: var(--hds-chatbox-form-background);
  border: var(--hds-chatbox-form-border);
  border-radius: var(--hds-chatbox-form-border-radius);
  padding: var(--hds-chatbox-form-padding);
}

.chat-form .chat-input-group {
  width: var(--hds-chatbox-form-input-width);
  display: grid;
  grid-template-columns: var(--hds-chatbox-form-input-grid-template-columns);
  align-items: center;
  border: var(--hds-chatbox-form-input-border);
  border-radius: var(--hds-chatbox-form-input-border-radius);
}

.chat-form .chat-input-group .chat-icon {
  height: var(--hds-chatbox-form-input-chat-icon-height);
  width: var(--hds-chatbox-form-input-chat-icon-width);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.chat-textbox {
  width: var(--hds-chatbox-form-input-chat-text-box-width);
  color: var(--hds-chatbox-form-input-chat-text-box-color);
  font-size: var(--hds-chatbox-form-input-chat-text-box-font-size);
  padding: var(--hds-chatbox-form-input-chat-text-box-padding);
  background: transparent;
  border-radius: var(--hds-chatbox-form-input-chat-border-radius);
  border: none;
  outline: none;
}

.chat-textbox::placeholder {
  color: var(--hds-chatbox-form-input-chat-placeholder-color);
  font-size: var(--hds-chatbox-form-input-chat-placeholder-font-size);
}

.chat-btn {
  outline: 0;
  border: 0;
  cursor: pointer;
  background: transparent;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
}
</style>
