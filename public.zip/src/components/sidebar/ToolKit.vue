<template>
  <div class="sidebar">
    <section
      class="sidebox"
      :style="{ display: `${isVisible ? 'Block' : 'none'}` }"
    >
      <div class="bottom">
        <slot name="com"></slot>
      </div>
    </section>

    <template v-for="section in toolkitItems" :key="section.section">
      <template v-if="section.section == 'Section 1'">
        <div
          @click="print"
          class="sidebaricon1"
          v-for="item in section.items"
          :key="item.label"
        >
          <img :src="item.icon" />
        </div>
      </template>
      <template v-if="section.section == 'Section 2'">
        <div
          @click="$emit('open')"
          class="sidebaricon2"
          v-for="item in section.items"
          :key="item.label"
        >
          <img :src="item.icon" />
        </div>
      </template>
      <template v-if="section.section == 'Section 3'">
        <div
          @click="$emit('open')"
          class="sidebaricon3"
          v-for="item in section.items"
          :key="item.label"
        >
          <img :src="item.icon" />
        </div>
      </template>
    </template>
  </div>
</template>

<script>
export default {
  name: "ToolKit",
  emits: ["open"],
  components: {},
  props: {
    toolkitItems: Array,
    // toolkitStyle: Object,
    isVisible: Boolean,
  },

  methods: {
    print() {
      console.log(this.ChatComponent);
    },
  },
};
</script>

<style>
@import "../../css/variable.css";
.sidebar {
  border: 1px solid #e7ecf1;
  box-shadow: rgba(0, 0, 0, 0.1) 0px 10px 15px -3px,
    rgba(0, 0, 0, 0.05) 0px 4px 6px -2px;
  /* background: grey; */
  height: 100vh;
  width: fit-content;
  margin-left: auto;
  position: relative;
}
.sidebar > div {
  padding: 0.5rem;
  border-radius: 3px;
}
.sidebar img {
  width: var(--hds-chatbox-header-logo-width);
  height: var(--hds-chatbox-header-logo-height);
}
.sidebaricon1 {
  border-radius: 3px;
  background: linear-gradient(135deg, #0074e8 0%, #a933fb 100%);
  border-bottom: 1px solid #e7ecf1;
}
.sidebaricon1:nth-child(3) {
  border-radius: 0;
  background: white;
}
.sidebaricon2 {
  border-radius: 3px;

  /* background: linear-gradient(135deg, #0074e8 0%, #a933fb 100%);
  --webkit--background-clip: text;
  color: transparent; */
}
.sidebox {
  min-width: 300px;
  height: 100%;
  border-left: 1px solid #e7ecf1;
  width: max-content;
  position: absolute;
  top: 0;
  right: 100%;
}

.sidebox > .bottom {
  height: 100%;
  display: flex;
  flex-direction: column;
}
</style>
