<template>
  <ToolKit
    :toolkitItems="toolkitItems"
    :toolkitStyle="toolkitStyle"
    :isVisible="isVisible"
    @open="this.isVisible = true"
  >
    <template v-slot:com>
      <Chat
        @close="this.isVisible = false"
        :chatBoxStyle="chatBoxStyle"
        :emptyChatContent="emptyChatContent"
        :chatBoxHeader="chatBoxHeader"
        :savedTemplates="savedTemplates"
        @SentMessage="sentMessage"
        :chatMessages="chatMessages"
      /> </template
  ></ToolKit>

  <div />
</template>

<script>
import { ToolKit, Chat } from "./components/index.js";
/* eslint-disable vue/no-unused-components */
export default {
  name: "app",

  components: {
    ToolKit,
    Chat,
  },
  data() {
    return {
      toolkitItems: [
        {
          section: "Section 1",
          items: [
            {
              label: "Ai",
              routerLink: "",
              icon: "./assets/icons/AI.svg",
              selectedIcon: "./assets/icons/ai-menu-white.svg",
              padding: 8,
            },
            {
              label: "Recent",
              routerLink: "",
              icon: "./assets/icons/history.svg",
              selectedIcon: "./assets/icons/recent.svg",
              padding: 10,
            },
          ],
        },
        {
          section: "Section 2",
          items: [
            {
              label: "Add",
              routerLink: "",
              icon: "./assets/icons/plus.svg",
              selectedIcon: "./assets/icons/plus-white.svg",
              padding: 10,
            },
            {
              label: "Notification",
              routerLink: "",
              icon: "./assets/icons/bell.svg",
              selectedIcon: "./assets/icons/notification-white.svg",
              padding: 10,
            },
            {
              label: "Setting",
              routerLink: "",
              icon: "./assets/icons/cog.svg",
              selectedIcon: "`./assets/icons/setting-white.svg",
              padding: 10,
            },
          ],
        },
        {
          section: "Section 3",
          items: [
            {
              label: "Chat",
              routerLink: "",
              icon: "./assets/icons/comments.svg",
              selectedIcon: "./assets/icons/chat-white.svg",
              padding: 10,
            },
          ],
        },
      ],
      // toolkitStyle: {
      //   iconWidth: "25px",
      //   iconHeight: "250px",
      //   toolkitHeight: "100vh",
      // },
      isVisible: false,

      //chat prop
      chatBoxStyle: {
        logo: "./assets/icons/ai-gradient.svg",
        inputBoxPlaceholder: "Ask your data question",
        inputAttachmentIcon: "pi pi-paperclip",
        actionDropDownIcon: "pi pi-ellipsis-h",
      },
      emptyChatContent: {
        showEmptyChatHeader: true,
        title: "AI-Driven Insights Companion",
        inputPlaceholder: "Ask your data question",
        searchIcon: "../assets/icons/search.svg",
      },
      chatBoxHeader: {
        title: "AI Board Exploration",
        showChatBoxHeader: true,
      },
      savedTemplates: {
        icon: "../assets/icons/search-blue.svg",
        title: "Or Start with Saved Templates",
        useTemplate: true,
        showSavedTemplate: true,
        templates: [
          {
            title: "Generate Monday Report",
            routerLink: "",
          },
          {
            title: "Show CINDE Insights Panel",
            routerLink: "",
          },
        ],
      },
      chatMessages: [],
    };
  },
  methods: {
    sentMessage(obj) {
      console.log(obj);
      this.chatMessages.push(obj, { ...obj, isAI: true });
    },
  },
};
</script>

<style scoped></style>
